const express = require('express');
const mysql = require('mysql2');
const multer = require('multer');
const path = require('path');
const cors = require('cors');

// Initialize Express app
const app = express();
const port = 3000;

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', 
  password: '',   database: 'test',
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL!');
});

// Setup Multer for image upload
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));
app.use(cors()); // Enable CORS

// Create images table (run this once to create the table)
// const createTable = `
//   CREATE TABLE IF NOT EXISTS images (
//     id INT AUTO_INCREMENT PRIMARY KEY,
//     name VARCHAR(255),
//     mime_type VARCHAR(255),
//     data LONGBLOB
//   );
// `;

// db.query(createTable, (err, result) => {
//   if (err) throw err;
//   console.log('Images table created or already exists');
// });

// Routes

// Create: Upload multiple images
app.post('/upload', upload.array('images'), (req, res) => {  
    const files = req.files;
    if (!files || files.length === 0) {
      return res.status(400).send('No images uploaded.');
    }
  
    let uploadedImages = 0;
    let totalImages = files.length;
  

    files.forEach((file) => {
      const name = req.body.name || 'Untitled';
      const mimeType = file.mimetype;
      const data = file.buffer;
  
      const query = 'INSERT INTO images (name, mime_type, data) VALUES (?, ?, ?)';
      db.query(query, [name, mimeType, data], (err, result) => {
        if (err) {
          return res.status(500).send('Error uploading images.');
        }
  
        uploadedImages++;
  
        // If all images have been uploaded, send the response
        if (uploadedImages === totalImages) {
          console.log("Image uploaded Sucessfully");
          
          res.send('Images uploaded successfully.');
        }
      });
    });
});

// Read: Get all images
app.get('/images', (req, res) => {
  const query = 'SELECT * FROM images';
  db.query(query, (err, result) => {
    if (err) {
      return res.status(500).send('Error fetching images.');
    }
    res.json(result);
  });
});

// Read: Get image by ID
app.get('/image/:id', (req, res) => {
  const { id } = req.params;

  const query = 'SELECT * FROM images WHERE id = ?';
  db.query(query, [id], (err, result) => {
    if (err) {
      return res.status(500).send('Error fetching image.');
    }
    if (result.length === 0) {
      return res.status(404).send('Image not found.');
    }
    const image = result[0];
    res.setHeader('Content-Type', image.mime_type);
    res.send(image.data);
  });
});

// Delete: Delete image by ID
app.delete('/image/:id', (req, res) => {
  const { id } = req.params;

  const query = 'DELETE FROM images WHERE id = ?';
  db.query(query, [id], (err, result) => {
    if (err) {
      return res.status(500).send('Error deleting image.');
    }
    if (result.affectedRows === 0) {
      return res.status(404).send('Image not found.');
    }
    res.send('Image deleted successfully.');
  });
});

// Update: Update image by ID
app.put('/image/:id', upload.single('image'), (req, res) => {
    const { id } = req.params;
    const { file } = req;
  
    if (!file && !req.body.name) {
      return res.status(400).send('No image or name to update.');
    }
  
    const name = req.body.name || '';
    let mimeType = '';
    let data = null;
  
    if (file) {
      mimeType = file.mimetype;
      data = file.buffer;
    }
  
    const updateQuery = 'UPDATE images SET name = ?, mime_type = ?, data = ? WHERE id = ?';
  
    // If no new image is provided, we still need to update the name
    if (!file) {
      db.query('UPDATE images SET name = ? WHERE id = ?', [name, id], (err, result) => {
        if (err) {
          return res.status(500).send('Error updating image name.');
        }
        if (result.affectedRows === 0) {
          return res.status(404).send('Image not found.');
        }
        res.send('Image name updated successfully.');
      });
    } else {
      db.query(updateQuery, [name, mimeType, data, id], (err, result) => {
        if (err) {
          return res.status(500).send('Error updating image.');
        }
        if (result.affectedRows === 0) {
          return res.status(404).send('Image not found.');
        }
        res.send('Image updated successfully.');
      });
    }
  });
  

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
