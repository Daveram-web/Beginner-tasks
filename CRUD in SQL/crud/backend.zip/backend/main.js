"Select * from employee where id =2"

"INSERT INTO  employee (name)  VALUES (A)"
"UPDATE employee  SET name = ? where id = 1"

"DELETE FROM employee WHERE id = 1"

